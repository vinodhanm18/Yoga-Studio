import React from 'react';
import { Link } from 'react-router-dom';
import '/Users/vinodhanm/React/vinodhan-react/src/assets/css/adminhome.css'; 

const AdminHomePage = () => {
  return (
    <div className="admin-container">
      <h1 className="admin-section-heading">Welcome, Admin!</h1>
      <div>
        <h2 className="admin-section-heading">Manage Classes</h2>
        <ul>
          <li className="admin-list-item"><Link className="admin-link" to="/admin/classes">View All Classes</Link></li>
          <li className="admin-list-item"><Link className="admin-link" to="/admin/classes/add">Add New Class</Link></li>
          <li className="admin-list-item"><Link className="admin-link" to="/admin/classes/schedule">Schedule Class</Link></li>
        </ul>
      </div>
      
    </div>
  );
};

export default AdminHomePage;
