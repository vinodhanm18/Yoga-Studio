// AdminClassesPage.jsx

import React from 'react';
import { Link } from 'react-router-dom';
import './AdminClassesPage.css'; // Import CSS file

const AdminClassesPage = () => {
  // Dummy data for demonstration
  const classes = [
    { id: 1, name: 'Morning Yoga', instructor: 'John Doe', time: '8:00 AM - 9:00 AM', room: 'Studio A' },
    { id: 2, name: 'Afternoon Meditation', instructor: 'Jane Smith', time: '12:00 PM - 1:00 PM', room: 'Studio B' },
    { id: 3, name: 'Evening Pilates', instructor: 'Alex Johnson', time: '5:00 PM - 6:00 PM', room: 'Studio C' }
  ];

  return (
    <div className="admin-container">
      <h1 className="admin-page-title">Manage Classes</h1>
      <div className="classes-list">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Instructor</th>
              <th>Time</th>
              <th>Room</th>
            </tr>
          </thead>
          <tbody>
            {classes.map(cls => (
              <tr key={cls.id}>
                <td>{cls.id}</td>
                <td>{cls.name}</td>
                <td>{cls.instructor}</td>
                <td>{cls.time}</td>
                <td>{cls.room}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="admin-actions">
        <Link className="admin-link" to="/admin/classes/add">Add New Class</Link>
        <Link className="admin-link" to="/admin/classes/schedule">Schedule Class</Link>
      </div>
    </div>
  );
};

export default AdminClassesPage;
